#!/usr/bin/env python3
"""Validate prerequisites for the exploratory OMXSB sibling-holdings first stage.

This entry point deliberately DOES NOT calculate holdings changes.  The legacy
parser converted missing identifiers/reports into zero and changed the tracker
population between endpoints.  Its saved 0.74 pp result is not validated here.

Run with --repo and --output-dir.  A blocked audit writes explicit NA outcomes
and exits 2.  Completing the listed audit inputs requires a separately reviewed
calculation; supplying a candidate row never makes an economic result valid.
"""
from __future__ import annotations

import argparse
import csv
from datetime import date, datetime, timezone
import hashlib
import json
from pathlib import Path

KINNEVIK_A_EFFECTIVE = date(2024, 6, 7)
KINNEVIK_A_VERIFIED_THROUGH = date(2024, 12, 31)
KINNEVIK_A_CURRENT = "SE0022060513"
KINNEVIK_A_STALE = "SE0015810239"
KINNEVIK_SOURCES = [
    "https://www.kinnevik.com/files/globalassets/documents/4.-governance/general-meetings/2024/Informationsbroschyr_2024_E.pdf",
    "https://view.news.eu.nasdaq.com/view?id=b6830b0cb904dc7457366e66c1056f5f1&lang=en",
]
OUTCOME_FIELDS = [
    "event_quantity_before", "event_quantity_after", "sister_quantity_before",
    "sister_quantity_after", "event_class_chg_pct", "event_class_chg_mn",
    "sister_chg_mn", "sister_hold_before_mn",
]
COMMON_BLOCKERS = [
    "candidate_pair_and_historical_listing_not_independently_cleared",
    "event_class_historical_identifier_chain_not_validated",
    "fixed_pre_event_tracker_population_and_dated_mandates_not_validated",
    "latest_complete_fund_reports_at_both_endpoints_not_validated",
    "both_class_instruments_and_absence_vs_missing_not_validated",
    "both_class_quantity_units_splits_and_corporate_actions_not_validated",
    "class_specific_denominators_not_validated",
]


def parse_date(value: str | None) -> date | None:
    try:
        return date.fromisoformat(str(value).strip()[:10])
    except (ValueError, TypeError):
        return None


def dated_sister_identifier(ric: str, share_class: str, snapshot: str) -> dict:
    """Only a source-verified dated override; never backdate a current ISIN."""
    when = parse_date(snapshot)
    is_kinnevik_a = ric.split(".")[0].upper() == "KINVA" and share_class.upper() == "A"
    if is_kinnevik_a and when and KINNEVIK_A_EFFECTIVE <= when <= KINNEVIK_A_VERIFIED_THROUGH:
        return {"isin": KINNEVIK_A_CURRENT, "status": "dated_source_verified",
                "effective_from": KINNEVIK_A_EFFECTIVE.isoformat(),
                "verified_through": KINNEVIK_A_VERIFIED_THROUGH.isoformat(),
                "sources": KINNEVIK_SOURCES}
    # The old Kinnevik ISIN is intentionally not assumed valid before this date;
    # earlier changes also require their own historical identifier evidence.
    return {"isin": None, "status": "unverified_historical_mapping",
            "effective_from": None, "sources": []}


def load_csv(path: Path, required: set[str]) -> list[dict]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        absent = required - set(reader.fieldnames or [])
        if absent:
            raise ValueError(f"{path}: missing columns {sorted(absent)}")
        return list(reader)


def file_record(path: Path) -> dict:
    return {"path": str(path.resolve()),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def build_validation_rows(candidates: list[dict], endpoints: dict[str, dict]) -> list[dict]:
    rows = []
    for candidate in candidates:
        ad = parse_date(candidate.get("AD"))
        if candidate.get("usable_pair", "").lower() != "true":
            continue
        # Missing dates are retained and blocked, never silently treated as no event.
        if ad is not None and ad < date(2019, 1, 1):
            continue
        event_id = candidate.get("event_id", "")
        endpoint = endpoints.get(event_id, {})
        before, after = endpoint.get("qb", ""), endpoint.get("qa", "")
        b = dated_sister_identifier(candidate.get("sister_ric", ""),
                                    candidate.get("sister_class", ""), before)
        a = dated_sister_identifier(candidate.get("sister_ric", ""),
                                    candidate.get("sister_class", ""), after)
        blockers = list(COMMON_BLOCKERS)
        if ad is None:
            blockers.append("announcement_date_missing_or_invalid")
        if not parse_date(before) or not parse_date(after):
            blockers.append("snapshot_dates_missing_or_invalid")
        if not b["isin"] or not a["isin"]:
            blockers.append("sister_class_historical_identifier_chain_not_validated")
        row = {"event_id": event_id, "review": candidate.get("review_cycle", ""),
               "company": candidate.get("company", ""), "type": candidate.get("type", ""),
               "AD": candidate.get("AD", ""), "before": before, "after": after,
               "sister_ric": candidate.get("sister_ric", ""),
               "sister_class": candidate.get("sister_class", ""),
               "candidate_listing_status": candidate.get("sister_listed_on_AD", ""),
               "sister_isin_before": b["isin"], "sister_isin_after": a["isin"],
               "sister_mapping_before_status": b["status"],
               "sister_mapping_after_status": a["status"],
               "mapping_sources": " | ".join(sorted(set(b["sources"] + a["sources"]))),
               "status": "blocked_not_an_economic_result",
               "missing_inputs": " | ".join(blockers)}
        row.update({field: None for field in OUTCOME_FIELDS})
        rows.append(row)
    return rows


def audit(repo: Path, output_dir: Path, candidates_path: Path | None = None) -> dict:
    repo, output_dir = repo.resolve(), output_dir.resolve()
    candidates_path = (candidates_path or repo / "code/claude_checks/twin_events.csv").resolve()
    # Prefer the corrected source for endpoint metadata.  No old quantity, return,
    # tracker classification or denominator is accepted as a validated input.
    endpoint_path = repo / "output/omxsb_audit_20261031/corrected/nettrading_omxsb.csv"
    if not endpoint_path.is_file():
        endpoint_path = repo / "output/omxsb_replication_2007/nettrading_omxsb.csv"
    output_dir.mkdir(parents=True, exist_ok=True)
    provenance, errors, rows = [], [], []
    candidates, endpoints = [], {}
    try:
        candidates = load_csv(candidates_path, {"event_id", "AD", "usable_pair", "sister_ric", "sister_class"})
        provenance.append(file_record(candidates_path))
    except (OSError, ValueError) as exc:
        errors.append(str(exc))
    try:
        endpoint_rows = load_csv(endpoint_path, {"event_id", "qb", "qa"})
        provenance.append(file_record(endpoint_path))
        for row in endpoint_rows:
            if row["event_id"] in endpoints:
                raise ValueError(f"Duplicate endpoint event_id: {row['event_id']}")
            endpoints[row["event_id"]] = row
    except (OSError, ValueError) as exc:
        errors.append(str(exc))
        endpoints = {}
    rows = build_validation_rows(candidates, endpoints)
    fields = list(rows[0]) if rows else ["event_id", "status", "missing_inputs"] + OUTCOME_FIELDS
    csv_path = output_dir / "first_stage_validation.csv"
    if csv_path == candidates_path or csv_path == endpoint_path:
        raise ValueError("Output would overwrite an input")
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: "NA" if value is None else value for key, value in row.items()})
    status = {
        "schema_version": 1, "status": "blocked_not_an_economic_result",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "mode": "validation_gate_only", "economic_computation_performed": False,
        "legacy_0_74_pp_validated": False, "candidate_rows_checked": len(rows),
        "validated_economic_rows": 0, "all_economic_outputs_are_NA": True,
        "global_input_errors": errors, "required_audits": COMMON_BLOCKERS,
        "inputs": provenance, "output_csv": str(csv_path),
        "kinnevik_a_override": {"effective_from": KINNEVIK_A_EFFECTIVE.isoformat(),
            "verified_through": KINNEVIK_A_VERIFIED_THROUGH.isoformat(),
            "isin": KINNEVIK_A_CURRENT, "stale_isin_not_used": KINNEVIK_A_STALE,
            "sources": KINNEVIK_SOURCES},
        "limitations": [
            "Candidate usable_pair is not verified listing, equal rights or price coverage.",
            "A corrected Kinnevik identifier does not validate holdings or true zero positions.",
            "No supplied quantity, return or prior aggregate is used to fill missing values.",
            "Legacy twin_first_stage_output.csv is preserved and is not a validated output.",
        ],
    }
    (output_dir / "first_stage_validation.json").write_text(
        json.dumps(status, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return status


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True, help="Explicit repository root")
    parser.add_argument("--output-dir", type=Path, required=True, help="Directory for new validation artifacts")
    parser.add_argument("--candidates", type=Path, help="Optional explicit candidate CSV")
    args = parser.parse_args()
    result = audit(args.repo, args.output_dir, args.candidates)
    print(json.dumps({key: result[key] for key in ["status", "candidate_rows_checked",
          "validated_economic_rows", "legacy_0_74_pp_validated", "output_csv"]}, ensure_ascii=False))
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
