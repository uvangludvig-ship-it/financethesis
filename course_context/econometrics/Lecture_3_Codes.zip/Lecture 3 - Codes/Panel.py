# BE451 - Degree project in Finance
# Panel data exercises
# Python version of Panel.r

# %%
# Load routinely-used packages
# pip install pandas numpy scipy statsmodels linearmodels matplotlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf
from scipy import stats
from statsmodels.stats.diagnostic import het_breuschpagan
from linearmodels.panel import PanelOLS, compare


# Question 1 -------------------------------------------------------------------
# %%
data = pd.read_stata("data/local_returns.dta")
print(data.head())

# %%

# (a) Descriptive statistics ----
# Is it a balanced or unbalanced panel? Provide aggregate summary statistics.

# %%
print(
    f"N = {data['permno'].nunique()}, "
    f"T = {data['date'].nunique()} "
    f"({data['date'].min():%Y-%m-%d} to {data['date'].max():%Y-%m-%d})"
)
print(f"Total obs. = {len(data)}")

# We observe 6,783 firms (stocks) and 132 time periods (months). Hence, a
# perfectly balanced panel would have over 895,000 observations, whereas we
# only have 487,582. Thus, the panel is clearly unbalanced.

# %%

# %%
firms_per_date = data.groupby("date").size()

plt.figure(figsize=(9, 5))
plt.bar(firms_per_date.index, firms_per_date.values, width=25)
plt.xlabel("Date")
plt.ylabel("Number of firms")
plt.title("Observed firms (stocks) over time")
plt.show()

# The number of observed stocks goes down over time, i.e. we observe more stocks
# in earlier periods than in recent ones.

# %%

# %%
# Many stocks are observed for the full 132 months in the dataset. Others are
# observed for various time ranges.
months_per_firm = data.groupby("permno").size()
print(months_per_firm.describe())

plt.figure(figsize=(7, 5))
plt.hist(months_per_firm, bins=20)
plt.xlabel("Number of observed months")
plt.ylabel("Number of firms")
plt.title("Distribution of observation windows")
plt.show()

# %%

# %%
# We can also provide some generic summary statistics.
def summary_custom(x: pd.Series) -> pd.Series:
    """Compute some summary statistics, dropping NA values."""
    x = x.dropna()
    return pd.Series({
        "mean": x.mean(),
        "sd": x.std(),  # sample sd (ddof = 1), same as R's sd()
        "skew": stats.skew(x),  # same as moments::skewness()
        "kurt": stats.kurtosis(x),  # excess kurtosis = moments::kurtosis() - 3
        "min": x.min(),
        "max": x.max(),
    })


vars_ = ["ret", "city_returns", "indret", "MRP", "HML", "RF", "MOM"]
summary_stats = data[vars_].apply(summary_custom)
print(summary_stats.round(4))

# Note the unbelievably high estimated kurtosis on 'ret', which is likely due
# to the observed maximum value of 15.8. This could be a data error!

# %%

# (b) Return statistics by city ----

# %%
# Start by computing mean returns and volatilities by city using groupby()
stats_by_city = data.groupby("city")["ret"].apply(summary_custom).unstack()

# Print the detail, and summarize the statistics
print(stats_by_city[["mean", "sd"]].round(4))
print(stats_by_city[["mean", "sd"]].describe())

# plot mean returns and volatilities by city
plt.figure(figsize=(7, 5))
plt.scatter(stats_by_city["mean"], stats_by_city["sd"])
plt.xlabel("Mean return")
plt.ylabel("Volatility")
plt.title("Mean returns and volatilities by city")
plt.show()

# Comments.
# There is substantial heterogeneity across cities with respect to mean returns,
# which range from 0.6% to 1.7%. A similar pattern can be observed for the
# volatility of returns.

# %%

# (c) Regression model set-up ----
# In what follows, we are interested in the following model:
#   ret = 1 + city_returns + indret       (3)

# Note: In what follows I use the 'linearmodels' package (PanelOLS), which plays
# the role of 'lfe'/'felm' in R. It needs the data indexed by (entity, time).

# %%
# Pooled OLS
# Estimate (3) using pooled OLS without dummies.
reg_2d = smf.ols("ret ~ city_returns + indret", data=data).fit()
print(reg_2d.summary())

# %%

# Testing for heteroskedasticity ----

# %%
# robust=False gives the original Breusch-Pagan test, like
# bptest(..., studentize = FALSE) in R.
bp_stat, bp_pval, _, _ = het_breuschpagan(
    reg_2d.resid, reg_2d.model.exog, robust=False
)
print(f"BP = {bp_stat:.2f}, p-value = {bp_pval:.4g}")

# Comments.
# As the test exhibits a p-value that is virtually zero, we reject the null
# hypothesis of homoskedasticity at all conventional confidence levels. This
# indicates that robust standard errors should be used (and they pretty much
# always should be).

# %%

# (d) fixed effects ----
# Could we use the city fixed effect?

# %%
# Set the panel index: entity = permno (firm), time = date.
# Note: 'date' is our time variable here (not 'year'!)
pdata = data.assign(permno=data["permno"].astype(int)).set_index(["permno", "date"])

# Time fixed effect ----
# PanelOLS uses the "within" transformation to include the time effects in an
# efficient manner (which keeps computation time low).
reg_2tf = PanelOLS.from_formula(
    "ret ~ city_returns + indret + TimeEffects", data=pdata
).fit()
print(reg_2tf)

# %%

# %%
# We can also proceed "manually" using OLS along with time dummies.
# Note that this is computationally much less efficient!
reg_2tf_manual = smf.ols("ret ~ city_returns + indret + C(date)", data=data).fit()

print(pd.DataFrame({
    "within (PanelOLS)": reg_2tf.params,
    "dummies (OLS)": reg_2tf_manual.params[["city_returns", "indret"]],
}))

# Comments.
# Note that the coefficient estimates for "city_returns" and "indret" are
# identical in both cases. As stated above, PanelOLS uses the "within"
# transformation to estimate the model with fixed effects. This requires
# computing time-specific means, and then running a simple OLS on the demeaned
# data. The approach is more efficient, but as a result, fixed effect estimates
# are not reported (and in most cases, we are not interested in those).
# There is almost never a need to use the "dummies" approach over this one.
#
# Note on R-squared: PanelOLS reports the *within* R-squared by default
# (after removing the fixed effects). R's felm() reports the full-model
# R-squared, which corresponds to 'reg.rsquared_inclusive' here.

# %%

# Firm fixed effect ----

# %%
reg_2ff = PanelOLS.from_formula(
    "ret ~ city_returns + indret + EntityEffects", data=pdata
).fit()
print(reg_2ff)

# gather two regression results together
print(compare({"Time FE": reg_2tf, "Firm FE": reg_2ff}, stars=True))

# %%

# (e) Two-way fixed effects ----

# %%
# Estimate (3) with both time and firm fixed effects.
reg_2g = PanelOLS.from_formula(
    "ret ~ city_returns + indret + EntityEffects + TimeEffects", data=pdata
).fit()
print(reg_2g)

print(compare({"Time FE": reg_2tf, "Firm FE": reg_2ff, "Two-way FE": reg_2g},
              stars=True))

# Comments.
# Overall the results do not change much when including firm fixed effects.
# Both coefficient estimates and the R-squared change little.
# The coefficient estimates are also quite close with those obtained by pooled
# OLS (i.e. without fixed effects) in (d). This suggests that unobserved
# time-specific and firm-specific variation play only a minor role for returns
# in this particular sample (while controlling for city-specific and industry-
# -specific returns).

# %%

# (f) Clustered standard errors ----

# %%
# Same two-way FE model, but with standard errors clustered by firm and time.
reg_2g_clse = PanelOLS.from_formula(
    "ret ~ city_returns + indret + EntityEffects + TimeEffects", data=pdata
).fit(cov_type="clustered", cluster_entity=True, cluster_time=True)

print(compare({"Time FE": reg_2tf, "Two-way FE": reg_2g,
               "Two-way FE, clustered": reg_2g_clse}, stars=True))

# Comments.
# Clearly, clustering the standard errors by both firm and time produces higher
# estimates than under the assumption of homoskedasticity.
# Intuitively, clustering relaxes assumptions on the cross-sectional and temporal
# independence of error terms, and thus produces more conservative standard errors.
# Note, however, that this is not always the case.
# (The small-sample corrections differ slightly from felm(), so the clustered
# standard errors may not match R to the last digit.)

# %%

# (i) Firm fixed effects ----

# %%
# Estimate (2) using the Fixed Effect (FE) estimator (e.g., firm fixed effect).
reg_2i = PanelOLS.from_formula(
    "ret ~ city_returns + indret + EntityEffects", data=pdata
).fit()
print(reg_2i)
print(compare({"Time FE": reg_2tf, "Two-way FE, clustered": reg_2g_clse,
               "Firm FE": reg_2i}, stars=True))

# %%
