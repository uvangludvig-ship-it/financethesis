#%%
library(haven)
data <- read_dta("Univ_data.dta")
colnames(data)
#%%
#%%
library(dplyr)
data$l_state_ap <- log(data$state_ap)
# Our-of-state first-year enrollment
data$l_AMERICAN_OOS <- log(data$AMERICAN_OOS)
# Research AAU nonResearch
#%%
#%%
model <- l_AMERICAN_OOS ~ l_state_ap + l_population  + factor(unitid) + factor(year)
reg <- lm(model, data=data, weights = weight,subset = (Research == 1)&(!is.na(l_ENROLL_FRESH_NON_RES_ALIEN_DEG)))
summary(reg)

#%%

#%%
model <- l_AMERICAN_OOS ~ l_state_ap + l_population + factor(unitid) + factor(year)
reg_fe <- lm(model , data=data, weights = weight,subset = (Research == 1)&(!is.na(l_ENROLL_FRESH_NON_RES_ALIEN_DEG)))
coef(reg_fe)[2:3,1:4]

library(lmtest)
library(sandwich)
coeftest(reg_fe, vcov = vcovCL(reg_fe, cluster = ~unitid))[2:3,1:4]
#%%
#%%
# install.packages(c("plm", "lmtest", "sandwich"))
library(plm)
library(lmtest)
library(sandwich)

pdata <- pdata.frame(data, index = c("unitid", "year"))

model <- l_AMERICAN_OOS ~ l_state_ap + l_population + factor(year)

reg_fe_plm <- plm(model , data=pdata, subset = (pdata$Research == 1)&(!is.na(pdata$l_ENROLL_FRESH_NON_RES_ALIEN_DEG)),  model = "within" , effect = "individual")

# "within", "random", "ht", "between", "pooling", "fd"

# "individual", "time", "twoways", "nested"

summary(reg_fe_plm)
coeftest(reg_fe_plm, vcov. = vcovHC(reg_fe_plm, type = "HC0", cluster = "group"))
#%%
#%%
#%%
