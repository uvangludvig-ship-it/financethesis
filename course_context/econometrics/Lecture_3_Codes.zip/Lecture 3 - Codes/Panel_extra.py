# Python version of Panel_extra.r
# Note: requires 'Univ_data.dta' in the working directory.

# %%
# pip install pandas numpy statsmodels linearmodels
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from linearmodels.panel import PanelOLS

data = pd.read_stata("Univ_data.dta")
print(data.columns.tolist())

# %%

# %%
data["l_state_ap"] = np.log(data["state_ap"])
# Out-of-state first-year enrollment
data["l_AMERICAN_OOS"] = np.log(data["AMERICAN_OOS"])
# Research AAU nonResearch

# %%

# %%
# Same sample restriction as the 'subset' argument in R
sample = data[
    (data["Research"] == 1) & data["l_ENROLL_FRESH_NON_RES_ALIEN_DEG"].notna()
]
model = "l_AMERICAN_OOS ~ l_state_ap + l_population + C(unitid) + C(year)"

# Weighted least squares with university and year dummies.
# missing="drop" mimics lm(), which silently drops rows with NA values.
reg = smf.wls(model, data=sample, weights=sample["weight"], missing="drop").fit()
print(reg.summary2().tables[1].loc[["l_state_ap", "l_population"]])

# %%

# %%
# Same model, now with standard errors clustered by university (unitid).
# Drop incomplete rows first so the cluster variable lines up with the sample.
cols = ["l_AMERICAN_OOS", "l_state_ap", "l_population", "unitid", "year", "weight"]
sample_cc = sample.dropna(subset=cols)
reg_fe = smf.wls(model, data=sample_cc, weights=sample_cc["weight"]).fit(
    cov_type="cluster", cov_kwds={"groups": sample_cc["unitid"]}
)
print(reg_fe.summary2().tables[1].loc[["l_state_ap", "l_population"]])

# %%

# %%
# The same within estimator with linearmodels (the counterpart of R's 'plm').
# Index = (entity, time) = (unitid, year). We keep a copy of 'year' as a column
# so that it can also be used for the year dummies in the formula.
pdata = sample.assign(year_fe=sample["year"]).set_index(["unitid", "year"])

# EntityEffects = university FE ("within", effect = "individual");
# the year dummies enter as regressors, just like factor(year) in the R code.
# Note: as in the plm() call in R, no weights are used here.
reg_fe_plm = PanelOLS.from_formula(
    "l_AMERICAN_OOS ~ l_state_ap + l_population + C(year_fe) + EntityEffects",
    data=pdata,
    drop_absorbed=True,
)
print(reg_fe_plm.fit())

# Standard errors clustered by university, like
# vcovHC(reg_fe_plm, type = "HC0", cluster = "group")
print(reg_fe_plm.fit(cov_type="clustered", cluster_entity=True))

# Other options:
#   PanelOLS(..., EntityEffects + TimeEffects)  -> effect = "twoways"
#   RandomEffects, BetweenOLS, FirstDifferenceOLS, PooledOLS
#   -> model = "random", "between", "fd", "pooling"

# %%
