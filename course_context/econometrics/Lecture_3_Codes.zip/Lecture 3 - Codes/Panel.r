# BE451 - Degree project in Finance
# Panel data exercises

# install packages if needed
# install.packages(c("haven", "sandwich", "lmtest", "stargazer","moments","lfe"))
# Load routinely-used packages
library(haven)
library(sandwich)
library(lmtest)
library(stargazer)


# Question 1 -------------------------------------------------------------------
data <- read_dta("data/local_returns.dta") 

head(data)

## (a) Descriptive statistics ----
# Is it a balanced or unbalanced panel? Provide aggregate summary statistics.


print(paste0(
  "N = ", length(unique(data$permno)), 
  ", T = ", length(unique(data$date)), 
  ' (', min(data$date), " to ", max(data$date), ')'
))
print(paste0("Total obs. = ", nrow(data)))

# We observe 6,783 firms (stocks) and 132 time periods (months). Hence, a
# perfectly balanced panel would have over 895,000 observations, whereas we
# only have 487,582. Thus, the panel is clearly unbalanced.

barplot(
  height = by(data, data$date, nrow),
  xlab = "Date",
  ylab = "Number of firms",
  main = "Observed firms (stocks) over time"
)

# The number of observed stocks goes down over time, i.e. we observe more stocks
# in earlier periods than in recent ones.



# Many stocks are observed for the full 132 months in the dataset. Others are
# observed for various time ranges.
summary(by(data, data$permno, nrow))
hist(
  x = by(data, data$permno, nrow),
  xlab = "Number of observed months",
  ylab = "Number of firms",
  main = "Distribution of observation windows"
)

# We can also provide some generic summary statistics.
library(moments)
summary_custom <- function(x, na.rm = FALSE) {
  # Computes some summary statistics, optionally removing NA values.
  if (na.rm) {
    x <- x[!is.na(x)]
  }
  return(c(
    "mean" = mean(x),
    "sd" = sd(x),
    "skew" = skewness(x),
    "kurt" = kurtosis(x) - 3,
    "min" = min(x),
    "max" = max(x)
  ))
}

vars <- c("ret", "city_returns", "indret", "MRP", "HML", "RF", "MOM")
stats <- apply(data[, vars], 2, summary_custom)
print(round(stats, 4))

# Note the unbelievably high estimated kurtosis on 'ret', which is likely due
# to the observed maximum value of 15.8. This could be a data error!

## (b) Return statistics by city ----

# Start by computing mean returns and volatilities by city using by()
stats_by_city <- by(data$ret, data$city, summary_custom)
stats_by_city <- as.data.frame(do.call(rbind, stats_by_city))

# Print the detail, and summarize the statistics
print(round(stats_by_city[, c("mean", "sd")], 4))
summary(stats_by_city[, c("mean", "sd")])

# plot mean returns and volatilities by city
plot(
  x = stats_by_city$mean, 
  y = stats_by_city$sd, 
  xlab = "Mean return",
  ylab = "Volatility",
  main = "Mean returns and volatilities by city"
)


# Comments.
# There is substantial heterogeneity across cities with respect to mean returns, 
# which range from 0.6% to 1.7%. A similar pattern can be observed for the 
# volatility of returns. 

## (c) Regression model set-up ----
# In what follows, we are interested in the following model:
#   ret = 1 + city_returns + indret       (3)


# Note: In what follows I use the 'lfe' package. Identical results can be
# obtained with 'plm', or by implementing fixed effect "manually" through lm().
library(lfe)

# Pooled OLS
# Estimate (3) using pooled OLS without dummies.
reg_2d <- felm(ret ~ city_returns + indret, data = data)
summary(reg_2d)

# Of course, we could also use lm() for this:
lm(ret ~ city_returns + indret, data = data)

# Testing for heteroskedasticity ----

bptest(reg_2d, studentize = FALSE)

# Comments.
# As the test exhibits a p-value that is virtually zero, we reject the null
# hypothesis of homoskedasticity at all conventional confidence levels. This
# indicates that robust standard errors should be used (and they pretty much 
# always should be).

## (d)  fixed effects ----
# Could we use the city fixed effect?

# Time fixed effect ----
# Note: 'date' is our time variable here (not 'year'!)
# The 'felm' function uses the "within" transformation to include the time
# effects in an efficient manner (which keeps computation time low).
reg_2tf <- felm(ret ~ city_returns + indret | date, data = data)
summary(reg_2tf)

# We can also proceed "manually" using lm() along with time dummies.
# Note that this is computationally much less efficient!
reg_2tf_manual <- lm(ret ~ city_returns + indret + factor(date), data = data)
print(reg_2tf_manual$coefficients[c("city_returns", "indret")])
stargazer(reg_2tf, reg_2tf_manual, type = "text")


# Comments.
# Note that the coefficient estimates for "city_returns" and "indret" are 
# identical in both cases. As stated above, the felm() function uses the
# "within" transformation to estimate the model with fixed effects. This requires
# computing time-specific means, and then running a simple OLS on the demeaned
# data. The approach is more efficient, but as a result, fixed effect estimates
# are not reported (and in most cases, we are not interested in those).
# There is almost never a need to use the "dummies" approach over this one.

# Firm fixed effect ----

reg_2ff <- felm(ret ~ city_returns + indret | permno, data = data)
summary(reg_2ff)

# gather two regression results togther
stargazer(reg_2tf, reg_2ff, type = "text")


##  (e) Two-way fixed effects ----
# Estimate (3) using pooled OLS with both time and firm fixed effects.
reg_2g <- felm(ret ~ city_returns + indret | date + permno, data = data)
summary(reg_2g)


stargazer(reg_2tf, reg_2ff, reg_2g, type = "text")

# Comments.
# Overall the results do not change much when including firm fixed effects.
# Both coefficient estimates and the R-squared change little.
# The coefficient estimates are also quite close with those obtained by pooled
# OLS (i.e. without fixed effects) in (d). This suggests that unobserved
# time-specific and firm-specific variation play only a minor role for returns
# in this particular sample (while controlling for city-specific and industry-
# -specific returns).



## (f) Clustered standard errors ----

reg_2g_clse <- felm(
  ret ~ city_returns + indret | date + permno | 0 | date + permno, 
  data = data
)
stargazer(reg_2tf, reg_2g, reg_2g_clse, type = 'text')

# Comments.
# Clearly, clustering the standard errors by both firm and time produces higher
# estimates than under the assumption of homoskedasticity.
# Intuitively, clustering relaxes assumptions on the cross-sectional and temporal
# independence of error terms, and thus produces more conservative standard errors.
# Note, however, that this is not always the case.

## (i) Firm fixed effects ----
# Estimate (2) using the Fixed Effect (FE) estimator (e.g., firm fixed effect).
reg_2i <- felm(ret ~ city_returns + indret | permno, data = data)
summary(reg_2i)
stargazer(reg_2tf, reg_2g_clse,reg_2i, type = 'text')
