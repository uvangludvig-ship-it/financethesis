#%%
# Question 3: pension.dta ------------------------------------------------------
# Python version of Q3.R

# %%
# pip install pandas numpy statsmodels
import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
from scipy import stats

## Import the data ----
# .dta files are a Stata proprietary format. pandas reads them directly, no
# extra package needed (this is the equivalent of R's haven::read_dta).
data_q2 = pd.read_stata("pension.dta")

print(data_q2.head())  # Inspect the first few rows of the data

# %%

# %%
## Counting single-person households ----
# How many single-person households are there in the data?
print((data_q2["fsize"] == 1).sum())

# There are 2017 single-person households in this dataset.

# %%

# %%
## Linear regression I ----
# Use OLS to estimate the model
#   nettfa = b0 + b1 * inc + b2 * age + u
# for the case of single-person households.
sample_1hh = data_q2[data_q2["fsize"] == 1]
reg_2c = smf.ols("nettfa ~ inc + age", data=sample_1hh).fit()
print(reg_2c.summary())

## Comments.
# A $1,000 increase in annual family income leads, on average and ceteris paribus,
# to a $799 increase in net financial wealth. Similarly, a one-year increase in
# the survey respondent's age leads, on average and ceteris paribus, to a $843
# increase in net financial wealth.
# More broadly, households with higher income tend to have larger wealth. Older
# respondents also tend to be wealthier on average, which is to be expected.

## Interpreting the intercept ----
# Does the intercept from the regression have an interesting meaning?

# The intercept of -43.0398 literally means that a single person with no income
# and age zero has a predicted net total financial asset of -43,039.8 dollars.
# Clearly this number makes little sense. This is due to the data comprising
# of individuals aged from 25 to 64 years only. Hence, the intercept represents
# a (poor) extrapolation to new-borns, which is of little interest.
# Technically, the intercept ensures that regression residuals are mean zero,
# and therefore it is not guaranteed to have a meaningful interpretation.

# %%

# %%
## Testing the significance of coefficients I ----
# Find the p-value for the test H0: beta_2 = 1 against H1: beta_2 < 1. Do you
# reject H0 at the 1% significance level?
# Note this is a one-sided t-test!
n = sample_1hh.shape[0]           # Get the number of observations
k = 2                             # Get the number of regressors
vc = reg_2c.cov_params()          # Get the OLS var-cov. matrix

# Compute the t-statistic as (Estimate - H0 value) / Std. Error
tstat = (reg_2c.params["age"] - 1) / np.sqrt(vc.loc["age", "age"])

# Compute the one-sided p-value using the Student-t distribution
pval = stats.t.cdf(-abs(tstat), df=n - k - 1)  # n-k-1 degrees of freedom
print(tstat, pval)

# Comments.
# This p-value ('pval') gives the probability that we would observe a test
# statistic less than -1.71 under the null hypothesis. Put differently, it
# reflects the probability that one observes a more extreme coefficient value
# if the null hypothesis is true.
# Since the p-value = 4% > 1%, we do not reject the null hypothesis that
# beta_2 = 1 at the 1% significance level, and against a one-sided alternative.

# %%

# %%
## Testing the significance of coefficients II ----
# Find the p-value for the test H0: beta_2 = 1 against H1: beta_2 != 1. Do you
# reject H0 at the 1% significance level?
# Note: Now we have a two-sided test. Because the Student-t distribution is
# symmetric, the p-value is simply twice that which was obtained before.
print(2 * pval)

# statsmodels can also do this directly:
print(reg_2c.t_test("age = 1"))

# Clearly, the conclusion is the same as before: We do not reject the null
# hypothesis that beta_2 = 1 against the two-sided alternative.

# %%

# %%
## Omitted variables ----
reg_2g = smf.ols("nettfa ~ inc", data=sample_1hh).fit()
print(reg_2g.summary())

# Comments.
# Beta_1 (0.82) here is marginally higher than the one from the initial
# regression (0.80). This positive bias is due to the positive effect of age
# on net wealth, and the positive correlation between age and income.
# The latter is only about 0.04, which results in the bias being small.
print(sample_1hh["age"].corr(sample_1hh["inc"]))

# %%

# %%
## Standardizing OLS coefficients ----
# Note: standardizing centers each variable around its sample mean and divides
# by its sample standard deviation - the equivalent of R's scale().
cols = ["nettfa", "inc", "age"]
tmp = sample_1hh[cols]
tmp = (tmp - tmp.mean()) / tmp.std()  # pandas std() uses ddof = 1, like R
reg_2m = smf.ols("nettfa ~ inc + age", data=tmp).fit()
print(reg_2m.summary())

# Compare to the coefficient estimates obtained in exercise 2c)
print(reg_2c.summary())

# Comments.
# Centering the dependent variable makes the intercept estimate equal to zero.
# Scaling explanatory variables as well leads to different coefficient estimates.
# In particular, the coefficients now measure by how many standard deviations the
# dependent variable changes in response to a one standard deviation increase in
# a given regressor. Note that because the coefficients are rescaled, standard
# errors are different as well.
# The standardization does not affect t-statistics, p-values, the R-squared, or
# the F-statistic. Therefore, the explanatory power of the standardized model is
# the same as that of the non-standardized one.

# %%

# %%
## Linear regression II ----
reg_2h = smf.ols("nettfa ~ inc + incsq + age + agesq + fsize", data=data_q2).fit()
print(reg_2h.summary())

# Comments.
# The relationship between net wealth and age seems to be better
# captured by the quadratic specification. The coefficient on 'age' is negative
# while that on 'agesq' is positive. This indicates that net wealth only
# increases in age after a certain point, while it rather decreases in age
# for young respondents (holding income fixed). In particular, one may rewrite
#   nettfa = ... - 1.258 * age + 0.026 * age^2 + ...
#          = ... + (0.026 * age - 1.258) * age + ...
# Hence, the total effect of age on net wealth is only positive for respondents
# aged 48 years (= 1.258 / 0.026) and older (holding income fixed).
# The conclusion is similar for the effect of income on net wealth. We may write
#   nettfa = ... - 0.13 * inc + 0.0095 * inc^2 + ...
#          = ... + (0.0095 * inc - 0.13) * inc + ...
# Net wealth only increases in income for households with an income of over
# $13,346 (0.127 / 0.0095 * $1,000).
# Importantly, coefficients on inc^2 and age^2 are strongly significant, while
# it is not the case for coefficients on inc and age. One interpretation (which
# we should further test) is that income and age have a positive effect on net
# wealth only for older households with high income. In any case, this
# regression indicates that we should think about nonlinear effects.
# Also note that larger families tend to have lower net wealth, ceteris paribus.

# %%
