
#%%
# Load essential libraries
library("readxl")
# install.packages('dplyr')
library('dplyr')

# Load the data
data <- read_excel("Anscombe_Data.xlsx")
head(data)
# Show the mean and standard deviation of the data for each variable
data %>% select(starts_with('x') | starts_with('y')) %>% summarise_all(mean)
data %>% select(starts_with('x') | starts_with('y')) %>% summarise_all(sd)
tempt <- data %>% select(starts_with('x') | starts_with('y')) %>% cor()
tail(t(head(round(tempt,2),4)),4)

#%%

#%%
c(lm(y1 ~ x1, data = data)$coefficients,lm(y2 ~ x2, data = data)$coefficients,lm(y3 ~ x3, data = data)$coefficients,lm(y4 ~ x4, data = data)$coefficients)

#%%

#%%
smoothness = 0.3
par(mfrow=c(2,2))
plot(data$x1,data$y1,main = "First Data",xlab = "x",ylab = "y",pch = 19, cex = 2, col = rgb(1,0,0,smoothness))
abline(lm(data$y1 ~ data$x1), col = "orange", lwd = 3)
plot(data$x2,data$y2,main = "Second Data",xlab = "x",ylab = "y",pch = 19, cex = 2, col = rgb(1,0,0,smoothness))
abline(lm(data$y2 ~ data$x2), col = "orange", lwd = 3)
plot(data$x3,data$y3,main = "Third Data",xlab = "x",ylab = "y",pch = 19, cex = 2, col = rgb(1,0,0,smoothness))
abline(lm(data$y3 ~ data$x3), col = "orange", lwd = 3)
plot(data$x4,data$y4,main = "Fourth Data",xlab = "x",ylab = "y",pch = 19, cex = 2, col = rgb(1,0,0,smoothness))
abline(lm(data$y4 ~ data$x4), col = "orange", lwd = 3)

#%%

