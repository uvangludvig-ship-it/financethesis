# Question 1: Anscombe's quartet -----------------------------------------------
# Python version of Q1.r

# %%
# Load essential libraries
# pip install pandas numpy statsmodels matplotlib openpyxl
import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import matplotlib.pyplot as plt

# Load the data
data = pd.read_excel("Anscombe_Data.xlsx")
print(data.head())

# Keep only the x* and y* columns
xy = data.filter(regex=r"^[xy]")

# Show the mean and standard deviation of the data for each variable
print(xy.mean())
print(xy.std())  # pandas uses the sample sd (ddof = 1), same as R's sd()

# Correlation between every x and every y
corr = xy.corr()
# The R code prints the lower-left block: corr(x_i, y_j)
print(corr.loc[["y1", "y2", "y3", "y4"], ["x1", "x2", "x3", "x4"]].round(2))

# %%

# %%
# Regress y on x in each of the four datasets
for i in range(1, 5):
    reg = smf.ols(f"y{i} ~ x{i}", data=data).fit()
    print(f"Dataset {i}: intercept = {reg.params.iloc[0]:.4f}, "
          f"slope = {reg.params.iloc[1]:.4f}")

# %%

# %%
# Plot the data and the regression line in each dataset
smoothness = 0.3
titles = ["First Data", "Second Data", "Third Data", "Fourth Data"]

fig, axes = plt.subplots(2, 2, figsize=(9, 8))
for i, ax in enumerate(axes.flat, start=1):
    x = data[f"x{i}"]
    y = data[f"y{i}"]

    ax.scatter(x, y, s=60, color="red", alpha=smoothness)

    # Regression line
    reg = smf.ols(f"y{i} ~ x{i}", data=data).fit()
    x_grid = np.linspace(x.min(), x.max(), 100)
    y_hat = reg.params.iloc[0] + reg.params.iloc[1] * x_grid
    ax.plot(x_grid, y_hat, color="orange", linewidth=3)

    ax.set_title(titles[i - 1])
    ax.set_xlabel("x")
    ax.set_ylabel("y")

fig.tight_layout()
plt.show()

# Comment.
# All four datasets share (almost) the same mean, standard deviation, correlation
# and regression line, yet they look completely different. Always plot your data.

# %%
