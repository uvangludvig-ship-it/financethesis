#%%
# Generate 1000 random numbers from a normal distribution with mean 0 and standard deviation 1
x <- rnorm(1000,0,1)
y <- rnorm(1000,0,1)
# Run a linear regression on the data
summary(lm(y ~ x))
#%%

#%%
gen_result <- function(){
    x <- rnorm(1000,0,1)
    y <- rnorm(1000,0,1)
    # Run a linear regression on the data
    reg <- summary(lm(y ~ x))
    coef <- reg$coefficients[2,1]
    sd <- reg$coefficients[2,2]
    t_stat <- reg$coefficients[2,3]
    pval <- reg$coefficients[2,4]
    return(list(coef,sd,t_stat,pval))
}

gen_result()
#%%
#%%
# Repeat the last step 1000 times. What fraction of estimations
# coefficients being statistically different from zero? What is the average
# value of the estimated coefficient?


library(foreach)
library(doParallel)
registerDoParallel(cores=4)
simulation_results <- foreach(i=1:1e5) %dopar% # or %do% if you don't want parallel
	gen_result()



library(data.table)
library(dplyr)
simulation_results <- as.data.frame(do.call(rbind, simulation_results)) # convert to data frame
simulation_results <- simulation_results %>% rename(coef = V1, sd = V2, t_stat = V3, pval = V4) # rename columns
head(simulation_results)
#%%
#%%
library(dplyr)
simulation_results %>% filter(pval < 0.05) %>% nrow() / 1e5
simulation_results %>% filter(t_stat > 1.96 | t_stat < -1.96) %>% nrow() / 1e5
#%%


# Q4

#%%
gen_result <- function(){
    x <- rnorm(1000,0,1)
    epsilon <- rnorm(1000,0,1)
    y <- 1 + 2*x + epsilon # DGP
    # Run a linear regression on the data
    reg <- summary(lm(y ~ x))
    coef <- reg$coefficients[2,1]
    sd <- reg$coefficients[2,2]
    t_stat <- reg$coefficients[2,3]
    pval <- reg$coefficients[2,4]
    return(list(coef,sd,t_stat,pval))
}
simulate_function <- function(){
    library(foreach)
    library(doParallel)
    registerDoParallel(cores=4)
    simulation_results <- foreach(i=1:1e3) %dopar% # or %do% if you don't want parallel
        gen_result()
    library(data.table)
    library(dplyr)
    simulation_results <- as.data.frame(do.call(rbind, simulation_results)) # convert to data frame
    simulation_results <- simulation_results %>% rename(coef = V1, sd = V2, t_stat = V3, pval = V4) # rename columns
    return(simulation_results)
}

simulation_results = simulate_function()
simulation_results %>% filter(pval < 0.05) %>% nrow() / 1e3
simulation_results %>% filter(t_stat > 1.96 | t_stat < -1.96) %>% nrow() / 1e3
#%%

#%%
simulation_results$t_stat_2 <- (as.numeric(simulation_results$coef)- 2) / as.numeric(simulation_results$sd)
simulation_results %>% filter(t_stat_2 > 1.96 | t_stat_2 < -1.96) %>% nrow() / 1e3
#%%


# Q5
#%%
x <- rnorm(1000,0,1)
epsilon <- rnorm(1000,0,1)
y <- 1 + 2*x + epsilon
data = data.frame(x,y)
reg <- lm(y ~ x)
data$residuals <- reg$residuals
data$y_hat <- reg$fitted.values
head(data)
#%%

#%%
plot(data$x, data$residuals, xlab="x", ylab="Residuals", main="Residuals vs Fitted")
#add a horizontal line at 0 
abline(0,0)
#%%

# Q6
#%%
gen_result <- function(){
    x <- rnorm(1000,0,1)
    epsilon <- rnorm(1000,10,1)
    z <- rnorm(1000,0,1)
    y <- 1 + 2*x + z + epsilon
    # Run a linear regression on the data
    reg <- summary(lm(y ~ x))
    coef <- reg$coefficients[2,1]
    sd <- reg$coefficients[2,2]
    t_stat <- reg$coefficients[2,3]
    pval <- reg$coefficients[2,4]
    return(list(coef,sd,t_stat,pval))
}
simulate_function <- function(){
    library(foreach)
    library(doParallel)
    registerDoParallel(cores=4)
    simulation_results <- foreach(i=1:1e3) %dopar% # or %do% if you don't want parallel
        gen_result()
    library(data.table)
    library(dplyr)
    simulation_results <- as.data.frame(do.call(rbind, simulation_results)) # convert to data frame
    simulation_results <- simulation_results %>% rename(coef = V1, sd = V2, t_stat = V3, pval = V4) # rename columns
    return(simulation_results)
}
simulation_results <- simulate_function()
mean(as.numeric(simulation_results$coef))
# Does the result change if you change the mean of the z?
#%%

#%%
gen_result <- function(){
    x <- rnorm(100000,0,1)
    epsilon <- rnorm(100000,0,1)
    mu <- rnorm(100000,0,1)
    z <- 1 + sqrt(x) + mu
    y <- 1 + 2*x + z + epsilon # DGP 
    # Run a linear regression on the data
    reg <- summary(lm(y ~ x))
    coef <- reg$coefficients[2,1]
    sd <- reg$coefficients[2,2]
    t_stat <- reg$coefficients[2,3]
    pval <- reg$coefficients[2,4]
    return(list(coef,sd,t_stat,pval))
}


simulation_results <- simulate_function()
mean(as.numeric(simulation_results$coef))
#%%

